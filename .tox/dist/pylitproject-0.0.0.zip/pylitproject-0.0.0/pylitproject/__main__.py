def main():
    print("pylitproject is running")

if __name__ == '__main__':
    main()
